package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button cToF;
    private TextView result;
    private EditText enterTemp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Referencing UI components
        cToF = findViewById(R.id.cToF);
        result = findViewById(R.id.result);
        enterTemp = findViewById(R.id.enterTemp);

        cToF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Convert the input temperature from EditText to double
                double temp = Double.parseDouble(enterTemp.getText().toString());
                // Convert Celsius to Fahrenheit
                double result1 = (temp * 1.8) + 32;
                // Display the result
                result.setText(String.valueOf(result1));
            }
        });
    }
}
