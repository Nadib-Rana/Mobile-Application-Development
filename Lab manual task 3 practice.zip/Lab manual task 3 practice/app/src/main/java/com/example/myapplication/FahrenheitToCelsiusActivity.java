package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class FahrenheitToCelsiusActivity extends AppCompatActivity {

    private Button fToC, cToFButton;
    private TextView resultF;
    private EditText enterTempF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fahrenheit_to_celsius);

        // Referencing UI components
        fToC = findViewById(R.id.fToC);
        resultF = findViewById(R.id.resultF);
        enterTempF = findViewById(R.id.enterTempF);
        cToFButton = findViewById(R.id.cToFButton);

        fToC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Convert the input temperature from EditText to double
                double tempF = Double.parseDouble(enterTempF.getText().toString());
                // Convert Fahrenheit to Celsius
                double resultC = (tempF - 32) / 1.8;
                // Display the result
                resultF.setText(String.valueOf(resultC));
            }
        });

        cToFButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Celsius to Fahrenheit activity
                Intent intent = new Intent(FahrenheitToCelsiusActivity.this, CelsiusToFahrenheitActivity.class);
                startActivity(intent);
            }
        });
    }
}
