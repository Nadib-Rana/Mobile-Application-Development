package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CelsiusToFahrenheitActivity extends AppCompatActivity {

    private Button cToF, backButton;
    private TextView result;
    private EditText enterTemp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_celsius_to_fahrenheit);

        // Referencing UI components
        cToF = findViewById(R.id.cToF);
        result = findViewById(R.id.result);
        enterTemp = findViewById(R.id.enterTemp);
        backButton = findViewById(R.id.backButton);

        cToF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Convert the input temperature from EditText to double
                double temp = Double.parseDouble(enterTemp.getText().toString());
                // Convert Celsius to Fahrenheit
                double result1 = (temp * 1.8) + 32;
                // Display the result
                result.setText(String.valueOf(result1));
            }
        });

        // Back button click listener
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // This will close the CelsiusToFahrenheitActivity and return to the LoginActivity
            }
        });
    }
}
